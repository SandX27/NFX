import discord
from discord.ext import commands


class _ticket(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    """Ticket commands"""
  
    def help_custom(self):
		      emoji = '<:tick:1396871774154657802>'
		      label = "Ticket"
		      description = ""
		      return emoji, label, description

    @commands.group()
    async def __Ticket__(self, ctx: commands.Context):
        """`setticket` , `ticket`"""