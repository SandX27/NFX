import os

TOKEN = os.environ.get("TOKEN")
NAME = "NFX"
server = "https:discord.gg/nfx"
ch = "https://discord.com/channels/699587669059174461/1271825678710476911"
OWNER_IDS = [1350448055282831361]
BotName = "NFX"
serverLink = "https:discord.gg/nfx"