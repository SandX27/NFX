import discord
from discord.ext import commands, tasks
import asyncio

class StatusCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.channel_id = 1385212481949012091
        self.message_id = None # Will store message ID after first send
        self.status_task.start()

    def cog_unload(self):
        self.status_task.cancel()

    @tasks.loop(seconds=30)
    async def status_task(self):
        channel = self.bot.get_channel(self.channel_id)
        if not channel:
            return

        uptime = discord.utils.utcnow() - self.bot.launch_time
        uptime_str = str(uptime).split('.')[0]  # Remove microseconds

        embed = discord.Embed(title="Code X Live Stats", color=0x2f3136)  # Default gray color

        # By default embed red & offline if bot not ready
        if not self.bot.is_ready():
            embed.color = 0xff0000  # Red
            embed.description = "**Status:** <a:status:1376168960231215196> Offline / Starting..."
        else:
            embed.color = 0x00ff00  # Green
            embed.description = "**Status:** <a:stats:1376168473406869645> Online"

            # Add stats only if online
            embed.add_field(name="Uptime <:asdsw:1396875150397407272> ", value=uptime_str, inline=False)
            embed.add_field(name="Ping <:signal:1396875161357258885>", value=f"{round(self.bot.latency * 1000)} ms", inline=False)
            embed.add_field(name="Guilds <a:serverupdate:1376167871008477294>", value=str(len(self.bot.guilds)), inline=False)
            embed.add_field(name="Users <:mem:1397150579230511205>", value=str(len(self.bot.users)), inline=False)
            embed.add_field(name="Commands <a:command:1376168021234560000>", value=str(len(self.bot.commands)), inline=False)  
            embed.add_field(name="Invite Link <:invite:1378788896967491666>", value="[Click Here](https://discord.com/oauth2/authorize?client_id=1397165129996435476&permissions=8&integration_type=0&scope=bot+applications.commands)", inline=False)
            embed.add_field(name="Website <:website:1378788763429244968>", value="[Visit NFx](https://discord.gg/nfx)", inline=False)
            

        embed.set_footer(text="By NFx Team")
        embed.set_thumbnail(url=self.bot.user.display_avatar.url)
        embed.set_image(url="https://cdn.discordapp.com/avatars/1396047821068701776/69ab23520f913668b3c89d16d21729a2.png?size=1024")

        # Send or edit message
        if self.message_id is None:
            msg = await channel.send(embed=embed)
            self.message_id = msg.id
        else:
            try:
                msg = await channel.fetch_message(self.message_id)
                await msg.edit(embed=embed)
            except discord.NotFound:
                # Message deleted, send new one
                msg = await channel.send(embed=embed)
                self.message_id = msg.id

    @status_task.before_loop
    async def before_status(self):
        await self.bot.wait_until_ready()

async def setup(bot):
    # Store bot launch time for uptime calc
    bot.launch_time = discord.utils.utcnow()
    await bot.add_cog(StatusCog(bot))
